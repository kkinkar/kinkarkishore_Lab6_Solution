package com.greatlearning.LabSession6.service;

import java.util.List;

import com.greatlearning.LabSession6.entity.Student;

public interface StudentService {

	void save(Student student);

	List<Student> findAll();

	Student findById(Integer id);

	void delete(Student student);

	List<Student> findByF_nameL_name(String f_name, String l_name);

}

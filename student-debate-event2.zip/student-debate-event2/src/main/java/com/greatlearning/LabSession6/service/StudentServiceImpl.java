package com.greatlearning.LabSession6.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.greatlearning.LabSession6.entity.Student;
import com.greatlearning.LabSession6.repositories.StudentRepository;

//1.update
//2.save
//3.delete
//4.findAll
@Service

public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepository studentRepo;

	@Override
	public List<Student> findAll() {
		return studentRepo.findAll();
	}

	@Override
	public void save(Student student) {
		studentRepo.save(student);	
	}

	@Override
	public Student findById(Integer id) {
		return studentRepo.findById(id).get();
	}

	@Override
	public void delete(Student student) {
		studentRepo.delete(student);		
	}

	@Override
	public List<Student> findByF_nameL_name(String f_name, String l_name) {
		return studentRepo.findByFnameContainsAndLnameContainsAllIgnoreCase(f_name, l_name);
	}

}

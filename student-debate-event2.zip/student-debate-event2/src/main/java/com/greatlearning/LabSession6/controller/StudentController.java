package com.greatlearning.LabSession6.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.greatlearning.LabSession6.entity.Student;
import com.greatlearning.LabSession6.service.StudentService;

@Controller
@RequestMapping("/student")


public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	// add mapping for "/list"

		@RequestMapping("/list")
		public String listStudent(Model theModel) {
			// get Students from db
			List<Student> theStudent = studentService.findAll();

			// add to the spring model
			theModel.addAttribute("student", theStudent);
			return "Student";
		}
		
		@RequestMapping("/addStudent")
		public String showFormForAdd(Model theModel) {

			// create model attribute to bind form data
			Student theStudent = new Student();

			theModel.addAttribute("student", theStudent);

			return "StudentForm";
		}
		
		@RequestMapping("/updateStudent")
		public String showFormForUpdate(@RequestParam("id") Integer theId,
				Model theModel) {

			// get the student from the service
			Student theStudent = studentService.findById(theId);


			// set student as a model attribute to pre-populate the form
			theModel.addAttribute("student", theStudent);

			// send over to our form
			return "StudentForm";			
		}
		
		@PostMapping("/save")
		public String saveBook(@RequestParam("id") Integer id,
				@RequestParam("f_name") String f_name,@RequestParam("l_name") String l_name,@RequestParam("country") String country, @RequestParam("course") String course) {

			System.out.println(id);
			Student theStudent;
			if(id!=0)
			{
				theStudent=studentService.findById(id);
				theStudent.setFname(f_name);
				theStudent.setLname(l_name);
				theStudent.setCountry(country);
				theStudent.setCourse(course);
			}
			else
				theStudent=new Student(f_name, l_name, country, course);
			// save the student
			studentService.save(theStudent);


			// use a redirect to prevent duplicate submissions
			return "redirect:/student/list";

		}
		
		@RequestMapping("/deleteStudent")
		public String delete(@RequestParam("id") Integer theId) {

			if(theId!=0)
			{
				Student theStudent=studentService.findById(theId);
				studentService.delete(theStudent);
			}
			
			// redirect to /Student/list
			return "redirect:/student/list";

		}
		
		@RequestMapping("/search")
		public String search(@RequestParam("f_name") String f_name,
				@RequestParam("l_name") String l_name,
				Model theModel) {

			// check names, if both are empty then just give list of all student
			if (f_name.trim().isEmpty() && l_name.trim().isEmpty()) {
				return "redirect:/student/list";
			}
			else {
				// else, search by name and last name
				List<Student> theStudent =studentService.findByF_nameL_name(f_name, l_name);

				// add to the spring model
				theModel.addAttribute("student", theStudent);

				// send to list-students
				return "Student";
			}
		}
		
		@RequestMapping("/403")
		public ModelAndView accessDenied(Principal user)
		{
			ModelAndView mv=new ModelAndView();
			
			if(user!=null)
			{
				mv.addObject("msg", "Hi "+user.getName()+", you are not allowed to access this page");			
			}
			else
			{
				mv.addObject("msg", "Hi, you are not allowed to access this page");	
			}
			mv.setViewName("403");
			return mv;
		}
}

